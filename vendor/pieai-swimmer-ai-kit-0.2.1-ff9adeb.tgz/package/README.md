# SwimmerAIKit

Small, server-only TypeScript primitives shared by Pie AI products.

## Scope

- Server environment readers and fallback resolution
- Product-owned model alias registries
- OpenRouter model configuration and attribution headers
- Generic OpenRouter chat completion transport
- Local provider budget reservation/commit/release guards
- Typed generator registries with optional provider-budget wrapping
- **Content safety** (`content-safety`): local text rules + Sightengine visual and
  adult-reference adapters
- **Dual TTS routing** (`tts`): language → western (ElevenLabs) / chinese (MiniMax) façade

The package deliberately does not own prompts, product model policy, game logic,
wallet RPCs, database access, or deployment topology. Each product deploys its
own Mastra service and supplies its own model aliases, budgets, and generators.

## Origins

The first extraction was made from behavior already present in TuringPact and
Show `main`. Show remains unchanged during this extraction; its separate
migration session can adopt the package later.

## Usage

Install from a pinned Git commit:

```json
{
  "dependencies": {
    "@pieai/swimmer-ai-kit": "github:PieAIStudio/SwimmerAIKit#<commit>"
  }
}
```

Import only the narrow module needed by the service:

```ts
import {
  createContentModerationProvider,
  ADULT_COMEDY_MODERATION_POLICY,
} from '@pieai/swimmer-ai-kit/content-safety';
import { createDualTtsRouter, resolveTtsRoute } from '@pieai/swimmer-ai-kit/tts';
import { firstDefinedEnv } from '@pieai/swimmer-ai-kit/env';
import {
  createModelRegistry,
  createOpenRouterModel,
} from '@pieai/swimmer-ai-kit/models';
import { requestOpenRouterChatCompletion } from '@pieai/swimmer-ai-kit/openrouter';
```

Assess a real-person reference separately from harmful-content moderation:

```ts
const moderation = createContentModerationProvider({
  sightengineApiUser: process.env.SIGHTENGINE_API_USER,
  sightengineApiSecret: process.env.SIGHTENGINE_API_SECRET,
});

const decision = await moderation.reviewAdultReference?.({
  kind: 'image',
  dataUrl: uploadedImageDataUrl,
});

if (decision?.status !== 'adult') {
  // Product decides how to explain minor, uncertain, or no_real_face.
}
```

The assessment uses Sightengine `face-age`, requires exactly one real face, and
fails closed when credentials, the classifier, or a reliable score are
unavailable. A normal photo of a minor is not labeled child exploitation: the
result is `minor_reference_detected`, a feature eligibility decision.

Secrets are inputs only. This package never stores, logs, or bundles secret
values.
